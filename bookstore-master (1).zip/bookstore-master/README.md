# Book-store | Knjižara
Bookstore for online shopping. This project has a AdminLTE Control Management System for manipulating with data.
First of all, what is important: Make new folder with name 'Book-store', and store it on htdocs.

Knjižara za online kupovinu. Ovaj projekat sadrži AdminLTE Control Management Sistem za manipulaciju podacima.
Ono što je važno: Napravite novi folder sa imenom 'Book-store', i smjestite ga u folderu htdocs.

### Video

https://www.youtube.com/watch?v=4ev3XkJ8FfA

